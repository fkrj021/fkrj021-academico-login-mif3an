package com.itb.mif3an.academicologinmif3an;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AcademicoLoginMif3anApplication {

	public static void main(String[] args) {
		SpringApplication.run(AcademicoLoginMif3anApplication.class, args);
	}

}
