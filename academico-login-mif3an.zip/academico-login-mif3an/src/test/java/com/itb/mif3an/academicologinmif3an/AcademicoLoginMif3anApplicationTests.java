package com.itb.mif3an.academicologinmif3an;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AcademicoLoginMif3anApplicationTests {

	@Test
	void contextLoads() {
	}

}
